import pygame, sys, random, asyncio
from pygame.locals import *
from resources.classes.reference_classes import Button
pygame.init()
 
# Colours
COLOR_BACKGROUND = (255, 255, 255)
 
# Game Setup
FPS = 60
fpsClock = pygame.time.Clock()
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
 
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption('Window')

#Title
TITLE_FONT_SIZE = 50
TITLE_FONT_COLOR = (0, 0, 0)
TITLE_CENTER = (WINDOW_WIDTH//2, 150)
TITLE_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', TITLE_FONT_SIZE)
TITLE = TITLE_FONT.render('Magic Spectrum', True, TITLE_FONT_COLOR)
TITLE_RECT = TITLE.get_rect()
TITLE_RECT.center = TITLE_CENTER

TITLE_LINE_START = (300, 200)
TITLE_LINE_END = (900, 200)


#Buttons
BUTTON_FONT_SIZE = 36
BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', BUTTON_FONT_SIZE)

START_BUTTON_POS = (350, 250)
START_BUTTON_DIMENSIONS = (500, 100)
START_BUTTON_COLOR = (255, 255, 255)
START_BUTTON_HCOLOR = (220, 220, 220)
START_BUTTON_PCOLOR = (180, 180, 180)
start_button = Button(START_BUTTON_POS, START_BUTTON_DIMENSIONS, START_BUTTON_COLOR)
start_button.add_border(8, (0, 0, 0))
start_button.add_text(BUTTON_FONT, 'Start Game!', (0, 0, 0), 3)

INSTRUCTIONS_BUTTON_POS = (350, 375)
INSTRUCTIONS_BUTTON_DIMENSIONS = (500, 100)
INSTRUCTIONS_BUTTON_COLOR = (255, 255, 255)
INSTRUCTIONS_BUTTON_HCOLOR = (220, 220, 220)
INSTRUCTIONS_BUTTON_PCOLOR = (180, 180, 180)
instructions_button = Button(INSTRUCTIONS_BUTTON_POS, INSTRUCTIONS_BUTTON_DIMENSIONS, INSTRUCTIONS_BUTTON_COLOR)
instructions_button.add_border(8, (0, 0, 0))
instructions_button.add_text(BUTTON_FONT, 'How to Play', (0, 0, 0), 3)

CREDITS_BUTTON_POS = (350, 500)
CREDITS_BUTTON_DIMENSIONS = (500, 100)
CREDITS_BUTTON_COLOR = (255, 255, 255)
CREDITS_BUTTON_HCOLOR = (220, 220, 220)
CREDITS_BUTTON_PCOLOR = (180, 180, 180)
credits_button = Button(CREDITS_BUTTON_POS, CREDITS_BUTTON_DIMENSIONS, CREDITS_BUTTON_COLOR)
credits_button.add_border(8, (0, 0, 0))
credits_button.add_text(BUTTON_FONT, 'Credits', (0, 0, 0), 3)


class Start_screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    #Start Button
    start_button.update(START_BUTTON_HCOLOR, START_BUTTON_PCOLOR, self.mousePos, self.mouseIsDown)
    if start_button.check_press(self.mousePos, self.mouseUp):
      return "ds"
    
    #Cosmetics Button
    instructions_button.update(INSTRUCTIONS_BUTTON_HCOLOR, INSTRUCTIONS_BUTTON_PCOLOR, self.mousePos, self.mouseIsDown)
    if instructions_button.check_press(self.mousePos, self.mouseUp):
      return "i_s"

    #Credits Button
    credits_button.update(CREDITS_BUTTON_HCOLOR, CREDITS_BUTTON_PCOLOR, self.mousePos, self.mouseIsDown)
    if credits_button.check_press(self.mousePos, self.mouseUp):
      return "cs"


    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)

    #Title
    WINDOW.blit(TITLE, TITLE_RECT)
    pygame.draw.line(WINDOW, (0, 0, 0), TITLE_LINE_START, TITLE_LINE_END, 8)
    
    #Buttons
    start_button.draw(WINDOW)
    instructions_button.draw(WINDOW)
    credits_button.draw(WINDOW)

    return "ss"
  







class Instructions_Screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None

    #Title
    self.title_font = BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 32)
    self.title = self.title_font.render("How to Play!", True, (0, 0, 0))
    self.title_rect = self.title.get_rect()
    self.title_rect.center = (WINDOW_WIDTH//2, 75)

    #Text
    self.text_image = pygame.image.load("resources/images/instructions_image.png")
    self.text_image = pygame.transform.scale(self.text_image, (1000, 600))
    self.text_image_coords = (100, 100)

    #Exit Button
    self.exit_button_font = BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 20)
    self.exit_button = Button((50, 50), (100, 50), (255, 255, 255))
    self.exit_button.add_border(0, (0, 0, 0))
    self.exit_button.add_text(self.exit_button_font, "<--", (0, 0, 0))
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    #Exit Button
    self.exit_button.update((230, 230, 230), (175, 175, 175), self.mousePos, self.mouseIsDown)
    if self.exit_button.check_press(self.mousePos, self.mouseUp):
      return "ss"


    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)
    
    WINDOW.blit(self.title, self.title_rect)

    WINDOW.blit(self.text_image, self.text_image_coords)

    self.exit_button.draw(WINDOW)

    return "i_s"
  




class Credits_Screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None

    #Title
    self.title_font = BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 32)
    self.title = self.title_font.render("Credits", True, (0, 0, 0))
    self.title_rect = self.title.get_rect()
    self.title_rect.center = (WINDOW_WIDTH//2, 75)

    #Text
    self.text_image = pygame.image.load("resources/images/credits_image.png")
    self.text_image = pygame.transform.scale(self.text_image, (1000, 600))
    self.text_image_coords = (100, 100)

    #Exit Button
    self.exit_button_font = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 20)
    self.exit_button = Button((50, 50), (100, 50), (255, 255, 255))
    self.exit_button.add_border(0, (0, 0, 0))
    self.exit_button.add_text(self.exit_button_font, "<--", (0, 0, 0))
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    #Exit Button
    self.exit_button.update((230, 230, 230), (175, 175, 175), self.mousePos, self.mouseIsDown)
    if self.exit_button.check_press(self.mousePos, self.mouseUp):
      return "ss"


    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)
    
    WINDOW.blit(self.title, self.title_rect)

    WINDOW.blit(self.text_image, self.text_image_coords)

    self.exit_button.draw(WINDOW)

    return "cs"