import pygame, sys, random, asyncio
from pygame.locals import *
from resources.classes.reference_classes import Button
pygame.init()
 
# Colours
COLOR_BACKGROUND = (255, 255, 255)
 
# Game Setup
FPS = 60
fpsClock = pygame.time.Clock()
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
 
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Window')


class Difficulty_Screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None

    #Title
    self.title_font = pygame.font.Font("resources/fonts/fff-forward.regular.ttf", 32)
    self.title = self.title_font.render("Select a Difficulty", True, (0, 0, 0))
    self.title_rect = self.title.get_rect()
    self.title_rect.center = (WINDOW_WIDTH//2, 150)

    #Easy Button
    self.btn_font = pygame.font.Font("resources/fonts/fff-forward.regular.ttf", 30)
    self.easy_btn = Button((200, 300), (200, 200), (0, 255, 0))
    self.easy_btn.add_border(5, (255, 255, 255))
    self.easy_btn.add_text(self.btn_font, "Easy", (255, 255, 255))

    #Medium Button
    self.medium_btn = Button((500, 300), (200, 200), (255, 255, 0))
    self.medium_btn.add_border(5, (255, 255, 255))
    self.medium_btn.add_text(self.btn_font, "Medium", (255, 255, 255))

    #Hard Button
    self.hard_btn = Button((800, 300), (200, 200), (255, 0, 0))
    self.hard_btn.add_border(5, (255, 255, 255))
    self.hard_btn.add_text(self.btn_font, "Hard", (255, 255, 255))

    #Recommended Text
    self.recommended_text_font = pygame.font.Font("resources/fonts/fff-forward.regular.ttf", 18)
    self.recommended_text = self.recommended_text_font.render("(recommended)", True, (0, 0, 0))
    self.recommended_text_rect = self.recommended_text.get_rect()
    self.recommended_text_rect.center = (600, 275)
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    self.easy_btn.update((0, 225, 0), (0, 150, 0), self.mousePos, self.mouseIsDown)
    if self.easy_btn.check_press(self.mousePos, self.mouseUp):
      return "gs", "easy"

    self.medium_btn.update((225, 225, 0), (150, 150, 0), self.mousePos, self.mouseIsDown)
    if self.medium_btn.check_press(self.mousePos, self.mouseUp):
      return "gs", "medium"

    self.hard_btn.update((225, 0, 0), (150, 0, 0), self.mousePos, self.mouseIsDown)
    if self.hard_btn.check_press(self.mousePos, self.mouseUp):
      return "gs", "hard"



    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)

    WINDOW.blit(self.title, self.title_rect)

    self.easy_btn.draw(WINDOW)
    self.medium_btn.draw(WINDOW)
    self.hard_btn.draw(WINDOW)

    WINDOW.blit(self.recommended_text, self.recommended_text_rect)

    return "ds", "medium"




