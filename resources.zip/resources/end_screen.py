import pygame, sys, random, asyncio
from pygame.locals import *
from resources.classes.reference_classes import Button
pygame.init()
 
# Colours
COLOR_BACKGROUND = (255, 0, 0)
 
# Game Setup
FPS = 60
fpsClock = pygame.time.Clock()
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
 
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption('Window')

#Title
TITLE_FONT_SIZE = 50
TITLE_FONT_COLOR = (255, 255, 255)
TITLE_CENTER = (WINDOW_WIDTH//2, 150)
TITLE_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', TITLE_FONT_SIZE)
TITLE = TITLE_FONT.render('Game Over', True, TITLE_FONT_COLOR)
TITLE_RECT = TITLE.get_rect()
TITLE_RECT.center = TITLE_CENTER

TITLE_LINE_START = (200, 200)
TITLE_LINE_END = (1000, 200)


#Buttons
BUTTON_FONT_SIZE = 36
BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', BUTTON_FONT_SIZE)

RESTART_BUTTON_POS = (350, 250)
RESTART_BUTTON_DIMENSIONS = (500, 100)
RESTART_BUTTON_COLOR = (255, 0, 0)
RESTART_BUTTON_HCOLOR = (220, 0, 0)
RESTART_BUTTON_PCOLOR = (180, 0, 0)
restart_button = Button(RESTART_BUTTON_POS, RESTART_BUTTON_DIMENSIONS, RESTART_BUTTON_COLOR)
restart_button.add_border(8, (255, 255, 255))
restart_button.add_text(BUTTON_FONT, 'Back to Home', (255, 255, 255), 3)


class End_screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    #Start Button
    restart_button.update(RESTART_BUTTON_HCOLOR, RESTART_BUTTON_PCOLOR, self.mousePos, self.mouseIsDown)
    if restart_button.check_press(self.mousePos, self.mouseUp):
      return "ss"


    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)

    #Title
    WINDOW.blit(TITLE, TITLE_RECT)
    pygame.draw.line(WINDOW, (255, 255, 255), TITLE_LINE_START, TITLE_LINE_END, 8)
    
    #Start Button
    restart_button.draw(WINDOW)

    return "es"




cs_TITLE_CENTER = (WINDOW_WIDTH//2, 100)
cs_TITLE = TITLE_FONT.render('You Won!', True, (255, 255, 255))
cs_TITLE_RECT = cs_TITLE.get_rect()
cs_TITLE_RECT.center = cs_TITLE_CENTER

class Completed_Screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = (0, 0, 0)


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None

    #variables
    self.current_zoom = 1
    self.zoom_speed = 5
    self.next = False
    self.init = False
    self.win_sound = pygame.mixer.Sound("resources/audio/win_sound.ogg")

    #map
    self.map = pygame.image.load("resources/images/map_all.png")
    self.map = pygame.transform.scale(self.map, (600, 600))
    self.map_rect = self.map.get_rect()
    self.map_rect.center = (600, 500)

    #Exit
    self.exit_button_font = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 20)
    self.exit_button = Button((50, 50), (100, 50), (0, 0, 0))
    self.exit_button.add_border(0, (0, 0, 0))
    self.exit_button.add_text(self.exit_button_font, "<--", (255, 255, 255))
    
  


  def run(self, events):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    #Zoom
    if self.current_zoom < 600:
      self.current_zoom += self.zoom_speed
    elif self.next != True:
      self.next = True
      self.init = True

    self.map = pygame.image.load("resources/images/map_all.png")
    self.map = pygame.transform.scale(self.map, (self.current_zoom, self.current_zoom))
    self.map_rect = self.map.get_rect()
    self.map_rect.center = (600, 500)

    #after
    if self.init:
      pygame.mixer.Sound.play(self.win_sound)
      self.init = False
    if self.next:
      #Exit Button
      self.exit_button.update((150, 150, 150), (50, 50, 50), self.mousePos, self.mouseIsDown)
      if self.exit_button.check_press(self.mousePos, self.mouseUp):
        return "ss"

    


    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)

    if self.next:
      WINDOW.blit(cs_TITLE, cs_TITLE_RECT)
      self.exit_button.draw(WINDOW)

    WINDOW.blit(self.map, self.map_rect)

    return "completed"







