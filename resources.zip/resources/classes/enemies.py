import math, pygame

class Enemy:
    def __init__(self, x, y, type) -> None:
        self.x = x
        self.y = y

        self.type = type
        if type == "green":
            self.image = pygame.image.load('resources/images/green_enemy0.png')
            self.image_rect = self.image.get_rect()
            self.speed = 1
            self.max_health = 30
            self.money = 10
            self.damage = 10
            self.pause_length = 60 #frames
        elif type == "red":
            self.image = pygame.image.load('resources/images/red_enemy0.png')
            self.image_rect = self.image.get_rect()
            self.speed = 2
            self.max_health = 100
            self.money = 100
            self.damage = 30
            self.pause_length = 30 #frames
        elif type == "blue":
            self.image = pygame.image.load('resources/images/blue_enemy0.png')
            self.image_rect = self.image.get_rect()
            self.speed = 4
            self.max_health = 100
            self.money = 200
            self.damage = 20
            self.pause_length = 120 #frames
        elif type == "yellow":
            self.image = pygame.image.load('resources/images/yellow_enemy0.png')
            self.image_rect = self.image.get_rect()
            self.speed = 5
            self.max_health = 500
            self.money = 500
            self.damage = 50
            self.pause_length = 60 #frames
        elif type == "rainbow":
            self.image = pygame.image.load('resources/images/rainbow_enemy.png')
            self.image_rect = self.image.get_rect()
            self.speed = 6
            self.max_health = 1500
            self.money = 2000
            self.damage = 150
            self.pause_length = 60 #frames

        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.HITBOX_OFFSET = 20
        
        self.health = self.max_health

        self.HEALTHBAR_OFFSET = 10
        self.HEALTHBAR_HEIGHT = 15
        self.HEALTHBAR_WIDTH = 100

        self.INVINCIBLE_TIMER = 11 #Frames
        self.INVINCIBLE_SPEED = .5
        self.invincible_frames = 0
        self.invincible = False

        self.current_speed = self.speed

        self.pause = False
        self.pause_frames = 0

        self.poison = False
        self.poison_length = 240 #Frames
        self.poison_frames = 0
        self.poison_strength = self.max_health*0.05

        self.freeze = False
        self.freeze_length = 120 #Frames
        self.freeze_frames = 0

        self.p_orientation = "left"
        self.frame_spacing = 10 #Frames
        self.image_frame = 0
        self.image_frames = 0
        self.last_image_frame = 0


    def update(self, WINDOW_WIDTH, WINDOW_HEIGHT, PLAYER_WIDTH, PLAYER_HEIGHT, damage):
        
        #Bullet Collisions
        #self.current_speed = self.speed
        #for bullet in bullets:
        #    if bullet.x-BULLET_RADIUS > self.x-self.HITBOX_OFFSET and bullet.y-BULLET_RADIUS > self.y-self.HITBOX_OFFSET and bullet.x+BULLET_RADIUS < self.x+self.width+self.HITBOX_OFFSET and bullet.y+BULLET_RADIUS < self.y+self.height+self.HITBOX_OFFSET:
        #        self.health-=damage
        #        self.invincible = True
        #if self.invincible:
        #    self.current_speed = self.INVINCIBLE_SPEED
        #    self.invincible_frames += 1
        #    if self.invincible_frames == self.INVINCIBLE_TIMER:
        #        self.invincible = False
        #        self.invincible_frames = 0


        #enemy_frames
        if not self.pause and not self.freeze:
            self.image_frames+=1
            if self.image_frames % self.frame_spacing == 0:
                self.image_frames = 0
                self.image_frame += 1
                if self.image_frame > 1:
                    self.image_frame = 0
        else:
            self.image_frame = self.last_image_frame

        if self.type == "green":
            self.image = pygame.image.load(f'resources/images/green_enemy{self.image_frame}.png')
        elif self.type == "red":
            self.image = pygame.image.load(f'resources/images/red_enemy{self.image_frame}.png')
        elif self.type == "blue":
            self.image = pygame.image.load(f'resources/images/blue_enemy{self.image_frame}.png')
        elif self.type == "yellow":
            self.image = pygame.image.load(f'resources/images/yellow_enemy{self.image_frame}.png')
        self.last_image_frame = self.image_frame

        #Positioning
        if not self.pause and not self.freeze:
            self.x1, self.y1 = self.x, self.y
            self.x2, self.y2 = WINDOW_WIDTH//2-self.width//2, WINDOW_HEIGHT//2-self.height//2
            self.distance = math.sqrt((self.x2 - self.x1)**2 + (self.y2 - self.y1)**2)
            if self.distance > self.current_speed:
                self.interval = self.distance / self.current_speed
                self.x_interval, self.y_interval = (self.x - self.x2)/self.interval, (self.y - self.y2)/self.interval
                self.x -= self.x_interval
                self.y -= self.y_interval
            else:
                self.x = self.x2
                self.y = self.y2
            if self.x_interval > 0 and self.p_orientation == "right":
                self.p_orientation = "left"
            elif self.x_interval < 0 and self.p_orientation == "left":
                self.p_orientation = "right"
            if self.p_orientation == "right":
                self.image = pygame.transform.flip(self.image, True, False)
            self.image_rect = self.image.get_rect()

        
        #Healthbar
        self.healthbar = pygame.Rect(self.x+self.width//2-self.HEALTHBAR_WIDTH//2, self.y-self.HEALTHBAR_OFFSET-self.HEALTHBAR_HEIGHT, self.HEALTHBAR_WIDTH, self.HEALTHBAR_HEIGHT)
        self.g_healthbar = pygame.Rect(self.x+self.width//2-self.HEALTHBAR_WIDTH//2, self.y-self.HEALTHBAR_OFFSET-self.HEALTHBAR_HEIGHT, self.HEALTHBAR_WIDTH/self.max_health*self.health, self.HEALTHBAR_HEIGHT)

        if not self.pause and not self.freeze:
            #if touching player
            if self.x > WINDOW_WIDTH//2-PLAYER_WIDTH//2-self.width and self.y > WINDOW_HEIGHT//2-PLAYER_HEIGHT//2-self.height and self.x < WINDOW_WIDTH//2+PLAYER_WIDTH//2 and self.y < WINDOW_HEIGHT//2+PLAYER_HEIGHT//2:
                self.x += self.x_interval*5/self.speed
                self.y += self.y_interval*5/self.speed
                self.pause = True
                return self.damage
        
        if self.pause:
            self.pause_frames += 1
            if self.pause_frames == self.pause_length: 
                self.pause = False
                self.pause_frames = 0

        #Poison
        if self.poison:
            self.poison_frames += 1
            if self.poison_frames % 60 == 0:
                self.health -= self.poison_strength
            if self.poison_frames >= self.poison_length:
                self.poison_frames = 0
                self.poison = False
        
        #Freeze
        if self.freeze:
            self.freeze_frames += 1
            if self.freeze_frames >= self.freeze_length:
                self.freeze_frames = 0
                self.freeze = False

        #Invincible/knockback indicator
        if self.invincible:
            self.current_speed = self.INVINCIBLE_SPEED
            self.invincible_frames += 1
            if self.invincible_frames == self.INVINCIBLE_TIMER:
                self.invincible = False
                self.invincible_frames = 0
                self.current_speed = self.speed
            if self.invincible_frames == 1:
                self.invincible_alpha = 100
            elif self.invincible_frames == 2:
                self.invincible_alpha = 150
            elif self.invincible_frames == 3:
                self.invincible_alpha = 200
            elif self.invincible_frames == 4:
                self.invincible_alpha = 230
            elif self.invincible_frames == 5:
                self.invincible_alpha = 210
            elif self.invincible_frames == 6:
                self.invincible_alpha = 190
            elif self.invincible_frames == 7:
                self.invincible_alpha = 150
            elif self.invincible_frames == 8:
                self.invincible_alpha = 100
            elif self.invincible_frames == 9:
                self.invincible_alpha = 75
            elif self.invincible_frames == 10:
                self.invincible_alpha = 50

        return 0

        
