import math, pygame, random

YELLOW_INNACCURACY = 35

RAINBOW_DAMAGE_MULT = 0.1
RAINBOW_DAMAGE_MULT_CAP = 10


class Bullet:
    def __init__(self, mousePos:tuple, WINDOW_WIDTH, WINDOW_HEIGHT, BULLET_SPEED, type, pierce, player_x, player_y):
        self.type = type
        self.radius = 10
        self.damage_mult = 1
        self.reload_mult = 1
        self.WINDOW_WIDTH = WINDOW_WIDTH
        self.WINDOW_HEIGHT = WINDOW_HEIGHT
        self.x1 = player_x
        self.y1 = player_y

        if type == "black":
            self.color = (0, 0, 0)
            self.knockback = 1
            self.mana_cost = 10
        elif type == "green":
            self.color = (0, 255, 0)
            self.damage_mult = 0.75
            self.knockback = 0.5
            self.mana_cost = 20
        elif type == "red":
            self.color = (255, 0, 0)
            self.damage_mult = 1.5
            self.knockback = 2
            self.mana_cost = 50
        elif type == "blue":
            self.color = (0, 91, 255)
            self.knockback = 0
            self.mana_cost = 40
        elif type == "yellow":
            self.color = (255, 255, 0)
            self.radius = 6
            self.damage_mult = 0.5
            self.knockback = 0.1
            self.mana_cost = 5
        elif type == "rainbow":
            self.color = (55, 0, 55)
            self.color_value = 255
            self.charge = True
            self.radius = 20
            self.knockback = 0
            self.mana_cost = 100 #NEED TO MODIFY IN MAIN UNDER #BULLETS PROCESSING

        if type == "yellow":
            self.x2, self.y2 = random.randint(mousePos[0]-YELLOW_INNACCURACY, mousePos[0]+YELLOW_INNACCURACY), random.randint(mousePos[1]-YELLOW_INNACCURACY, mousePos[1]+YELLOW_INNACCURACY)
        else:
            self.x2, self.y2 = mousePos[0], mousePos[1]
        self.distance = math.sqrt((self.x2 - self.x1)**2 + (self.y2 - self.y1)**2)
        self.interval = self.distance / BULLET_SPEED
        self.x_interval, self.y_interval = (self.x2-WINDOW_WIDTH//2)/self.interval, (self.y2-WINDOW_HEIGHT//2)/self.interval
        #self.x_interval = self.x3 - self.x1
        #self.y_interval = self.x3 - self.x1

        self.rx = WINDOW_WIDTH//2
        self.ry = WINDOW_HEIGHT//2
        self.x, self.y = self.rx, self.ry

        self.hit_enemies = []
        self.pierces = pierce
        if type == "rainbow":
            self.pierces = 1000


        

    def update(self, mouseUp, mousePos, BULLET_SPEED):

        #print(f"{self.x3}, {self.y3}")
        #print(self.distance)
        if self.type != "rainbow":
            self.rx += self.x_interval
            self.ry += self.y_interval

            self.x = self.rx//1
            self.y = self.ry//1
        else:
            if not self.charge:
                self.rx += self.x_interval
                self.ry += self.y_interval

                self.x = self.rx//1
                self.y = self.ry//1

            elif mouseUp:
                self.charge = False
            elif self.charge:
                self.x2, self.y2 = mousePos[0], mousePos[1]
                self.distance = math.sqrt((self.x2 - self.x1)**2 + (self.y2 - self.y1)**2)
                self.interval = self.distance / BULLET_SPEED
                self.x_interval, self.y_interval = (self.x2-self.WINDOW_WIDTH//2)/self.interval, (self.y2-self.WINDOW_HEIGHT//2)/self.interval
                self.rx = self.WINDOW_WIDTH//2
                self.ry = self.WINDOW_HEIGHT//2
                self.x, self.y = self.rx, self.ry
                if self.damage_mult < RAINBOW_DAMAGE_MULT_CAP:
                    self.damage_mult += RAINBOW_DAMAGE_MULT
                    self.color_value -= 2
                    self.color = (255, self.color_value, 255)
                else:
                    self.damage_mult = RAINBOW_DAMAGE_MULT_CAP
                    self.color = (255, 0, 255)
    




