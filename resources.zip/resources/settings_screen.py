import pygame, sys, random, asyncio
from pygame.locals import *
from resources.classes.reference_classes import *
pygame.init()
 
# Colours
COLOR_BACKGROUND = (255, 255, 255)
 
# Game Setup
FPS = 60
fpsClock = pygame.time.Clock()
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
 
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption('Window')

#Title
TITLE_FONT_SIZE = 50
TITLE_FONT_COLOR = (0, 0, 0)
TITLE_CENTER = (WINDOW_WIDTH//2, 100)
TITLE_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', TITLE_FONT_SIZE)
TITLE = TITLE_FONT.render('Settings', True, TITLE_FONT_COLOR)
TITLE_RECT = TITLE.get_rect()
TITLE_RECT.center = TITLE_CENTER

SLIDER_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 10)

SUBLABEL_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 15)

VOLUME_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 30)

OPTION_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 20)



class Settings_Screen:
  #Initializes all of the variables that are needed for the screen to work
  def __init__(self):

    #STATE
    self.running = False
    
    #COLORS
    self.color_bg = COLOR_BACKGROUND

    #General
    self.settings = {}


    #USERINPUTS
    self.mouseIsDown = False
    self.mouseUp = False
    self.mouseDown = False
    self.mousePos = None

    #Exit Button
    self.exit_button_font = BUTTON_FONT = pygame.font.Font('resources/fonts/fff-forward.regular.ttf', 20)
    self.exit_button = Button((50, 50), (100, 50), (255, 255, 255))
    self.exit_button.add_border(0, (0, 0, 0))
    self.exit_button.add_text(self.exit_button_font, "<--", (0, 0, 0))

    #Volume Slider
    self.volume = 75
    self.volume_slider = Slider((600, 25), (300, 300), (50, 50), 0, 100, self.volume)
    self.volume_slider.change_slider(slider_rect_color=(100, 100, 255))
    self.volume_slider.add_text(SLIDER_FONT, (0, 0, 0))
    self.volume_slider.enableBarFilling((100, 100, 255))

    #Volume Slider Text
    self.volume_slider_text = VOLUME_FONT.render("Volume", True, (0, 0, 0))
    self.volume_slider_text_rect = self.volume_slider_text.get_rect()
    self.volume_slider_text_rect.center = (WINDOW_WIDTH//2, self.volume_slider.y - 50)

    #Music
    self.music_on = True
    self.music_buttons = RadioButtons(2, 20, [(250, 450), (350, 450)], 1)
    self.music_buttons.add_labels(SUBLABEL_FONT, 0, 40, (0, 0, 0), ["Off", "On"])

    #Music Text
    self.music_text = OPTION_FONT.render("Music", True, (0, 0, 0))
    self.music_text_rect = self.music_text.get_rect()
    self.music_text_rect.center = ((self.music_buttons.coords[1][0]-self.music_buttons.coords[0][0])//2+self.music_buttons.coords[0][0], self.music_buttons.coords[0][1]-50)

    #Sound Effects
    self.sfx_on = True
    self.sfx_buttons = RadioButtons(2, 20, [(550, 450), (650, 450)], 1)
    self.sfx_buttons.add_labels(SUBLABEL_FONT, 0, 40, (0, 0, 0), ["Off", "On"])

    #Sound Effects Text
    self.sfx_text = OPTION_FONT.render("Sound Effects", True, (0, 0, 0))
    self.sfx_text_rect = self.sfx_text.get_rect()
    self.sfx_text_rect.center = ((self.sfx_buttons.coords[1][0]-self.sfx_buttons.coords[0][0])//2+self.sfx_buttons.coords[0][0], self.sfx_buttons.coords[0][1]-50)

    #Camera Shake Button
    self.camera_shake_on = True
    self.camera_shake_buttons = RadioButtons(2, 20, [(850, 450), (950, 450)], 1)
    self.camera_shake_buttons.add_labels(SUBLABEL_FONT, 0, 40, (0, 0, 0), ["Off", "On"])

    #Camera Shake Button Text
    self.camera_shake_text = OPTION_FONT.render("Camera Shake", True, (0, 0, 0))
    self.camera_shake_text_rect = self.camera_shake_text.get_rect()
    self.camera_shake_text_rect.center = ((self.camera_shake_buttons.coords[1][0]-self.camera_shake_buttons.coords[0][0])//2+self.camera_shake_buttons.coords[0][0], self.camera_shake_buttons.coords[0][1]-50)

    #Hitboxes Buttons
    self.hitboxes_on = True
    self.hitbox_buttons = RadioButtons(2, 20, [(250, 650), (350, 650)], 0)
    self.hitbox_buttons.add_labels(SUBLABEL_FONT, 0, 40, (0, 0, 0), ["Off", "On"])

    #Hitbox Button Text
    self.hitbox_text = OPTION_FONT.render("Enable Hitboxes", True, (0, 0, 0))
    self.hitbox_text_rect = self.hitbox_text.get_rect()
    self.hitbox_text_rect.center = ((self.hitbox_buttons.coords[1][0]-self.hitbox_buttons.coords[0][0])//2+self.hitbox_buttons.coords[0][0], self.hitbox_buttons.coords[0][1]-50)

    #Nearest Enemy Buttons
    self.ne_on = True
    self.ne_buttons = RadioButtons(2, 20, [(550, 650), (650, 650)], 1)
    self.ne_buttons.add_labels(SUBLABEL_FONT, 0, 40, (0, 0, 0), ["Off", "On"])

    #Nearest Enemy Button Text
    self.ne_text = OPTION_FONT.render("Nearest Enemy Indicator", True, (0, 0, 0))
    self.ne_text_rect = self.ne_text.get_rect()
    self.ne_text_rect.center = ((self.ne_buttons.coords[1][0]-self.ne_buttons.coords[0][0])//2+self.ne_buttons.coords[0][0], self.ne_buttons.coords[0][1]-50)

  def run(self, events, previous_screen):
    
    """GETS USER INPUTS"""
    self.mouseDown = False
    self.mouseUp = False
    self.mousePos = pygame.mouse.get_pos()
    for event in events:
      if event.type == QUIT :
        pygame.quit()
        sys.exit()
      if event.type == MOUSEBUTTONDOWN:
        self.mouseIsDown = True
        self.mouseDown = True
      if event.type == MOUSEBUTTONUP:
        self.mouseIsDown = False
        self.mouseUp = True
    

    """PROCESSING"""
    self.volume_slider.update(self.mousePos, self.mouseDown, self.mouseUp)
    self.music_buttons.update(self.mousePos, self.mouseUp, self.mouseDown)
    self.sfx_buttons.update(self.mousePos, self.mouseUp, self.mouseDown)
    self.camera_shake_buttons.update(self.mousePos, self.mouseUp, self.mouseDown)
    self.hitbox_buttons.update(self.mousePos, self.mouseUp, self.mouseDown)
    self.ne_buttons.update(self.mousePos, self.mouseUp, self.mouseDown)

    self.settings["volume"] = self.volume_slider.step
    self.settings["music"] = self.music_buttons.selected_index
    self.settings["sfx"] = self.sfx_buttons.selected_index
    self.settings["camera_shake"] = self.camera_shake_buttons.selected_index
    self.settings["hitboxes"] = self.hitbox_buttons.selected_index
    self.settings["ne"] = self.ne_buttons.selected_index

    #print(self.settings)


    #Exit Button
    self.exit_button.update((230, 230, 230), (175, 175, 175), self.mousePos, self.mouseIsDown)
    if self.exit_button.check_press(self.mousePos, self.mouseUp):
      return previous_screen, self.settings



    """DRAW TO SCREEN"""
    WINDOW.fill(self.color_bg)

    WINDOW.blit(TITLE, TITLE_RECT)

    self.volume_slider.draw(WINDOW)
    WINDOW.blit(self.volume_slider_text, self.volume_slider_text_rect)

    self.music_buttons.draw(WINDOW)
    WINDOW.blit(self.music_text, self.music_text_rect)

    self.sfx_buttons.draw(WINDOW)
    WINDOW.blit(self.sfx_text, self.sfx_text_rect)
    
    self.camera_shake_buttons.draw(WINDOW)
    WINDOW.blit(self.camera_shake_text, self.camera_shake_text_rect)

    self.hitbox_buttons.draw(WINDOW)
    WINDOW.blit(self.hitbox_text, self.hitbox_text_rect)
    
    self.ne_buttons.draw(WINDOW)
    WINDOW.blit(self.ne_text, self.ne_text_rect)

    self.exit_button.draw(WINDOW)


    return "sets", self.settings



